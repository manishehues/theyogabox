<?php
/** Template Name: testing 
 */
get_header('testing'); ?>

<?php get_footer(); ?>

